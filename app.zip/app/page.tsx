import Navbar from '../components/Navbar'
import Hero from '../components/Hero'
import Services from '../components/Services'
import About from '../components/About'
import Projects from '../components/Projects'
import Achievements from '../components/Achievements'
import MediaGallery from '../components/MediaGallery'
import Clients from '../components/Clients'
import Contact from '../components/Contact'
import Footer from '../components/Footer'

export default function Home() {
  return (
    <main className='bg-black text-white overflow-hidden'>

      <Navbar />

      {/* SPACE BETWEEN NAVBAR & ABOUT */}
      <div className='pt-24'></div>

      {/* ABOUT SECTION UPPER */}
      <About />

      <Hero />

      <Services />

      <Projects />

      <Achievements />

      <MediaGallery />

      <Clients />

      <Contact />

      <Footer />

    </main>
  )
}